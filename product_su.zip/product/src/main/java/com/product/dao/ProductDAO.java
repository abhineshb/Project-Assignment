/*package com.product.dao;

import java.util.List;
import java.util.Map;

import com.product.model.Product;

public interface ProductDAO {

	public void addAllProduct(List<Product> list);
	public void addProduct(Product p);
	
	public List<Product> getAllProduct();
	public Product getProduct(long id);
	
	public void removeAllProduct();
	public void removeProduct(long id);
	
	public void updateAllProduct(List<Product> list);
	public void updateProduct(long id);
}
*/